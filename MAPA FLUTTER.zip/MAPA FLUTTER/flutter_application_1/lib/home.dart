import 'dart:async';

import 'package:flutter/material.dart';
import 'package:google_maps_flutter/google_maps_flutter.dart';

class HomePage extends StatefulWidget {
  HomePage({Key? key}) : super(key: key);

  @override
  _HomePageState createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  Completer<GoogleMapController> _controller = Completer();
  List<Marker> marker = [];

  @override
  void initState() {
    marcadores();
    super.initState();
  }

  void marcadores() {
    Marker etiquetauno = Marker(
      markerId: MarkerId('etiqueta1'),
      position: LatLng(13.35, -88.45),
      infoWindow: InfoWindow(title: 'MovilSV'),
      icon: BitmapDescriptor.defaultMarkerWithHue(BitmapDescriptor.hueBlue),
    );

    Marker etiquetados = Marker(
      markerId: MarkerId('etiqueta2'),
      position: LatLng(13.4833, -88.1833),
      infoWindow: InfoWindow(title: 'MovilSV'),
      icon: BitmapDescriptor.defaultMarkerWithHue(BitmapDescriptor.hueBlue),
    );
    Marker etiquetatres = Marker(
      markerId: MarkerId('etiqueta3'),
      position: LatLng(14.18333, -89.05),
      infoWindow: InfoWindow(title: 'MovilSV'),
      icon: BitmapDescriptor.defaultMarkerWithHue(BitmapDescriptor.hueBlue),
    );

    Marker etiquetacuatro = Marker(
      markerId: MarkerId('etiqueta4'),
      position: LatLng(13.3333300, -87.8500000),
      infoWindow: InfoWindow(title: 'MovilSV'),
      icon: BitmapDescriptor.defaultMarkerWithHue(BitmapDescriptor.hueBlue),
    );
    setState(() {
      marker.add(etiquetauno);
      marker.add(etiquetados);
      marker.add(etiquetatres);
      marker.add(etiquetacuatro);
    });
  }

  static final CameraPosition _kGooglePlex = CameraPosition(
    target: LatLng(13.69, -89.19),
    zoom: 14.4746,
  );

  @override
  Widget build(BuildContext context) {
    return GoogleMap(
      mapType: MapType.normal,
      initialCameraPosition: _kGooglePlex,
      markers: marker.map((e) => e).toSet(),
      onMapCreated: (GoogleMapController controller) {
        _controller.complete(controller);
      },
    );
  }
}
